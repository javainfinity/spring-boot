package com.javainfinity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavainfinitySpringBootRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavainfinitySpringBootRestApiApplication.class, args);
	}

}
