package com.javainfinity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {
	
	@GetMapping("/greeting")
	public Greeting greeting(@RequestParam(value="name", defaultValue = "John") String name) {
		String greeting = "Hello World ! "+name;
		Greeting greet = new Greeting();
		greet.setContent(greeting);
		
		return greet;
	}
}
