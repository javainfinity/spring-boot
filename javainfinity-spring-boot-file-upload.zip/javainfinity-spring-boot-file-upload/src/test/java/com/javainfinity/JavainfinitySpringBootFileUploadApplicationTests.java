package com.javainfinity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavainfinitySpringBootFileUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
