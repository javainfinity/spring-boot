package com.javainfinity;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class StorageServiceImpl implements StorageService{

	@Override
	public void store(MultipartFile multipartFile) {
		/*Logic to store you file in database.
		 * Depending upon your database for e.g MySql or MongoDB the logic can be implemented.
		 * */
	}
}
